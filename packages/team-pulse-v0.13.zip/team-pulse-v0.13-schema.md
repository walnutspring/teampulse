# Team Pulse schema (v0.13)

Current app version: v0.13
Current schema version: 1

## Portable JSON file shape

```json
{
  "schemaVersion": 1,
  "appVersion": "v0.13",
  "createdAt": "2026-04-14T10:00:00.000Z",
  "savedAt": "2026-04-14T10:05:00.000Z",
  "state": {
    "reports": [],
    "thresholds": {
      "oneOnOneDays": 14,
      "developmentConversationDays": 90,
      "cvReviewDays": 180
    },
    "settings": {
      "missingMentorCounts": true,
      "blockedPlanCounts": true,
      "saveReminderMinutes": 15
    }
  }
}
```

## State fields

### reports[]
- `id` string — stable readable ID for the person, for example `p_001`
- `name` string
- `level` string
- `mentors` string
- `hireDate` string in `YYYY-MM-DD`
- `lastPromotionDate` string in `YYYY-MM-DD`
- `nextOneOnOneDate` string in `YYYY-MM-DD`
- `planStatus` string — user-facing label is **PDC status**
- `riskFlag` string — user-facing label is **Support level**
- `developmentGoalSummary` string
- `promotionReadiness` string
- `notes` string
- `customFields[]` array of `{ id, label, value }`
- `meetings[]` array of `{ id, meetingType, meetingDate, notes, createdAt }`
- `createdAt` ISO 8601 timestamp
- `updatedAt` ISO 8601 timestamp

### thresholds
- `oneOnOneDays` number
- `developmentConversationDays` number
- `cvReviewDays` number

### settings
- `missingMentorCounts` boolean
- `blockedPlanCounts` boolean
- `saveReminderMinutes` number

## Migration scaffold

Team Pulse v0.13 includes the migration scaffold in code. Future migrations should be kept forever and run in order.

Planned shape:
- v1 -> v2: `MIGRATIONS[1] = (doc) => upgradedDoc`
- v2 -> v3: `MIGRATIONS[2] = (doc) => upgradedDoc`

Legacy files without `schemaVersion` are treated as pre-v1 and are upgraded into schema v1 when loaded.
