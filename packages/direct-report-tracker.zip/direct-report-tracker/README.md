# Direct Report Tracker

A very small web app for tracking:

- direct report profile info
- mentors
- last 1:1s
- last personal development conversations
- development plan status
- notes, growth areas, and reminders

This version is intentionally simple:

- single user
- no login
- SQLite database stored locally
- no external Python packages required

## Features

- Dashboard with summary cards
- "Needs attention" panel
- Per-report detail page
- Meeting history for 1:1s and development conversations
- Automatic reminders for:
  - 1:1 older than 14 days
  - development conversation older than 90 days
  - missing mentor
  - blocked plan

## Run it

From this folder:

```bash
python app.py
```

Then open:

```text
http://127.0.0.1:8000
```

## Data storage

The app creates a local SQLite file named `tracker.db` in the same folder.

## Main fields in v1

Each direct report stores:

- name
- role / title
- level
- team
- mentor(s)
- next planned 1:1
- development goal summary
- personal development plan status
- promotion readiness / growth area
- risk / attention flag
- notes

Meeting history stores:

- meeting type
- meeting date
- notes

The dashboard derives the latest 1:1 and development conversation dates from meeting history.

## Notes

This is designed as a starter version for easy iteration. Natural next steps would be:

- add filters and sorting
- export to CSV
- add custom reminder thresholds
- add richer note categories
- add a timeline view
