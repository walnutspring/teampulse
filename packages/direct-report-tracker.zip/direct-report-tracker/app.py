#!/usr/bin/env python3
from __future__ import annotations

import html
import os
import re
import sqlite3
from datetime import date, datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / 'tracker.db'
STATIC_DIR = BASE_DIR / 'static'
HOST = os.environ.get('TRACKER_HOST', '127.0.0.1')
PORT = int(os.environ.get('TRACKER_PORT', '8000'))

PLAN_STATUSES = [
    'Not started',
    'In progress',
    'Blocked',
    'Completed',
    'Needs review',
]

RISK_FLAGS = [
    'None',
    'Watch',
    'Needs attention',
    'Urgent',
]

MEETING_TYPES = [
    '1:1',
    'Development conversation',
]


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn


def init_db() -> None:
    conn = get_connection()
    with conn:
        conn.executescript(
            '''
            CREATE TABLE IF NOT EXISTS direct_reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                role_title TEXT,
                level TEXT,
                team TEXT,
                mentors TEXT,
                next_one_on_one_date TEXT,
                development_goal_summary TEXT,
                plan_status TEXT NOT NULL DEFAULT 'Not started',
                promotion_readiness TEXT,
                risk_flag TEXT NOT NULL DEFAULT 'None',
                notes TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS meetings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                report_id INTEGER NOT NULL,
                meeting_type TEXT NOT NULL,
                meeting_date TEXT NOT NULL,
                notes TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (report_id) REFERENCES direct_reports (id) ON DELETE CASCADE
            );
            '''
        )
    conn.close()


def now_iso() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat()


def esc(value: Any) -> str:
    if value is None:
        return ''
    return html.escape(str(value), quote=True)


def parse_iso_date(value: str | None) -> date | None:
    if not value:
        return None
    try:
        return date.fromisoformat(value)
    except ValueError:
        return None


def format_date(value: str | None) -> str:
    dt = parse_iso_date(value)
    return dt.strftime('%b %d, %Y') if dt else 'Not logged'


def days_since(value: str | None) -> int | None:
    dt = parse_iso_date(value)
    if not dt:
        return None
    return (date.today() - dt).days


def compute_attention(row: sqlite3.Row | dict[str, Any]) -> list[str]:
    issues: list[str] = []
    last_one_on_one = row['last_one_on_one']
    last_dev_conversation = row['last_dev_conversation']
    if not row['mentors']:
        issues.append('No mentor assigned')
    one_on_one_age = days_since(last_one_on_one)
    if one_on_one_age is None or one_on_one_age > 14:
        issues.append('1:1 overdue')
    dev_age = days_since(last_dev_conversation)
    if dev_age is None or dev_age > 90:
        issues.append('Development conversation overdue')
    if row['plan_status'] == 'Blocked':
        issues.append('Plan is blocked')
    if row['risk_flag'] in {'Needs attention', 'Urgent'}:
        issues.append(f"Risk flagged: {row['risk_flag']}")
    return issues


def fetch_reports() -> list[sqlite3.Row]:
    conn = get_connection()
    rows = conn.execute(
        '''
        SELECT
            dr.*,
            (
                SELECT MAX(meeting_date)
                FROM meetings m
                WHERE m.report_id = dr.id AND m.meeting_type = '1:1'
            ) AS last_one_on_one,
            (
                SELECT MAX(meeting_date)
                FROM meetings m
                WHERE m.report_id = dr.id AND m.meeting_type = 'Development conversation'
            ) AS last_dev_conversation
        FROM direct_reports dr
        ORDER BY dr.name COLLATE NOCASE
        '''
    ).fetchall()
    conn.close()
    return rows


def fetch_report(report_id: int) -> sqlite3.Row | None:
    conn = get_connection()
    row = conn.execute(
        '''
        SELECT
            dr.*,
            (
                SELECT MAX(meeting_date)
                FROM meetings m
                WHERE m.report_id = dr.id AND m.meeting_type = '1:1'
            ) AS last_one_on_one,
            (
                SELECT MAX(meeting_date)
                FROM meetings m
                WHERE m.report_id = dr.id AND m.meeting_type = 'Development conversation'
            ) AS last_dev_conversation
        FROM direct_reports dr
        WHERE dr.id = ?
        ''',
        (report_id,),
    ).fetchone()
    conn.close()
    return row


def fetch_meetings(report_id: int) -> list[sqlite3.Row]:
    conn = get_connection()
    rows = conn.execute(
        '''
        SELECT *
        FROM meetings
        WHERE report_id = ?
        ORDER BY meeting_date DESC, id DESC
        ''',
        (report_id,),
    ).fetchall()
    conn.close()
    return rows


def upsert_report(report_id: int | None, form: dict[str, str]) -> tuple[bool, str | None, int | None]:
    name = form.get('name', '').strip()
    if not name:
        return False, 'Name is required.', None

    plan_status = form.get('plan_status', 'Not started')
    if plan_status not in PLAN_STATUSES:
        plan_status = 'Not started'

    risk_flag = form.get('risk_flag', 'None')
    if risk_flag not in RISK_FLAGS:
        risk_flag = 'None'

    values = (
        name,
        form.get('role_title', '').strip(),
        form.get('level', '').strip(),
        form.get('team', '').strip(),
        form.get('mentors', '').strip(),
        form.get('next_one_on_one_date', '').strip(),
        form.get('development_goal_summary', '').strip(),
        plan_status,
        form.get('promotion_readiness', '').strip(),
        risk_flag,
        form.get('notes', '').strip(),
    )

    conn = get_connection()
    with conn:
        if report_id is None:
            cur = conn.execute(
                '''
                INSERT INTO direct_reports (
                    name, role_title, level, team, mentors, next_one_on_one_date,
                    development_goal_summary, plan_status, promotion_readiness,
                    risk_flag, notes, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''',
                values + (now_iso(), now_iso()),
            )
            new_id = int(cur.lastrowid)
        else:
            conn.execute(
                '''
                UPDATE direct_reports
                SET name = ?, role_title = ?, level = ?, team = ?, mentors = ?,
                    next_one_on_one_date = ?, development_goal_summary = ?,
                    plan_status = ?, promotion_readiness = ?, risk_flag = ?,
                    notes = ?, updated_at = ?
                WHERE id = ?
                ''',
                values + (now_iso(), report_id),
            )
            new_id = report_id
    conn.close()
    return True, None, new_id


def add_meeting(form: dict[str, str]) -> tuple[bool, str | None, int | None]:
    report_id_raw = form.get('report_id', '').strip()
    try:
        report_id = int(report_id_raw)
    except ValueError:
        return False, 'Invalid report.', None

    meeting_type = form.get('meeting_type', '')
    if meeting_type not in MEETING_TYPES:
        return False, 'Meeting type is required.', report_id

    meeting_date = form.get('meeting_date', '').strip()
    if not parse_iso_date(meeting_date):
        return False, 'Meeting date is required.', report_id

    conn = get_connection()
    with conn:
        conn.execute(
            '''
            INSERT INTO meetings (report_id, meeting_type, meeting_date, notes, created_at)
            VALUES (?, ?, ?, ?, ?)
            ''',
            (
                report_id,
                meeting_type,
                meeting_date,
                form.get('notes', '').strip(),
                now_iso(),
            ),
        )
    conn.close()
    return True, None, report_id


def delete_report(report_id: int) -> None:
    conn = get_connection()
    with conn:
        conn.execute('DELETE FROM direct_reports WHERE id = ?', (report_id,))
    conn.close()


def render_layout(title: str, body: str) -> bytes:
    page = f'''<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{esc(title)} - Direct Report Tracker</title>
  <link rel="stylesheet" href="/static/styles.css">
</head>
<body>
  <div class="page-shell">
    <header class="site-header">
      <div>
        <p class="eyebrow">Personal management tracker</p>
        <h1><a href="/">Direct Report Tracker</a></h1>
        <p class="subtle">A lightweight tracker for 1:1s, development conversations, and growth plans.</p>
      </div>
      <nav class="actions-row">
        <a class="button secondary" href="/">Dashboard</a>
        <a class="button" href="/report/new">Add direct report</a>
      </nav>
    </header>
    <main>
      {body}
    </main>
  </div>
</body>
</html>'''
    return page.encode('utf-8')


def status_badge(label: str, variant: str = '') -> str:
    cls = 'badge'
    if variant:
        cls += f' {variant}'
    return f'<span class="{cls}">{esc(label)}</span>'


def variant_for_plan(status: str) -> str:
    return {
        'Completed': 'success',
        'Blocked': 'danger',
        'Needs review': 'warning',
        'In progress': 'info',
    }.get(status, 'neutral')


def variant_for_risk(flag: str) -> str:
    return {
        'Urgent': 'danger',
        'Needs attention': 'warning',
        'Watch': 'info',
    }.get(flag, 'neutral')


def reminder_badges(row: sqlite3.Row | dict[str, Any]) -> str:
    badges: list[str] = []
    one_on_one_age = days_since(row['last_one_on_one'])
    if one_on_one_age is None or one_on_one_age > 14:
        badges.append(status_badge('1:1 overdue', 'warning'))
    dev_age = days_since(row['last_dev_conversation'])
    if dev_age is None or dev_age > 90:
        badges.append(status_badge('Development overdue', 'warning'))
    if not row['mentors']:
        badges.append(status_badge('No mentor', 'neutral'))
    if row['plan_status'] == 'Blocked':
        badges.append(status_badge('Blocked plan', 'danger'))
    return ''.join(badges) if badges else status_badge('On track', 'success')


def summary_cards(reports: list[sqlite3.Row]) -> str:
    total = len(reports)
    one_on_one_overdue = sum(1 for r in reports if days_since(r['last_one_on_one']) is None or days_since(r['last_one_on_one']) > 14)
    dev_overdue = sum(1 for r in reports if days_since(r['last_dev_conversation']) is None or days_since(r['last_dev_conversation']) > 90)
    blocked = sum(1 for r in reports if r['plan_status'] == 'Blocked')
    no_mentor = sum(1 for r in reports if not r['mentors'])
    cards = [
        ('Direct reports', total),
        ('1:1s overdue', one_on_one_overdue),
        ('Dev conversations overdue', dev_overdue),
        ('Blocked plans', blocked),
        ('No mentor assigned', no_mentor),
    ]
    pieces = []
    for label, value in cards:
        pieces.append(
            f'''<section class="card stat-card">
                  <p class="stat-value">{value}</p>
                  <p class="stat-label">{esc(label)}</p>
                </section>'''
        )
    return '<section class="card-grid">' + ''.join(pieces) + '</section>'


def render_dashboard() -> bytes:
    reports = fetch_reports()
    attention_items = []
    row_html = []

    for row in reports:
        issues = compute_attention(row)
        if issues:
            items = ''.join(f'<li>{esc(issue)}</li>' for issue in issues)
            attention_items.append(
                f'''<article class="attention-item">
                      <div>
                        <h3><a href="/report/{row['id']}">{esc(row['name'])}</a></h3>
                        <ul>{items}</ul>
                      </div>
                      <div class="attention-meta">{status_badge(row['plan_status'], variant_for_plan(row['plan_status']))}</div>
                    </article>'''
            )

        row_html.append(
            f'''<tr>
                  <td>
                    <a class="inline-link strong" href="/report/{row['id']}">{esc(row['name'])}</a>
                    <div class="subtle small">{esc(row['role_title'] or 'No title set')}</div>
                  </td>
                  <td>{esc(row['level'] or '-')}</td>
                  <td>{esc(row['mentors'] or '-')}</td>
                  <td>{esc(format_date(row['last_one_on_one']))}</td>
                  <td>{esc(format_date(row['last_dev_conversation']))}</td>
                  <td>{status_badge(row['plan_status'], variant_for_plan(row['plan_status']))}</td>
                  <td>{status_badge(row['risk_flag'], variant_for_risk(row['risk_flag']))}</td>
                  <td>{reminder_badges(row)}</td>
                </tr>'''
        )

    if reports:
        table = f'''<section class="card">
          <div class="section-header">
            <div>
              <h2>Current team view</h2>
              <p class="subtle">This table shows the latest status for each direct report.</p>
            </div>
          </div>
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Level</th>
                  <th>Mentor(s)</th>
                  <th>Last 1:1</th>
                  <th>Last development conversation</th>
                  <th>Plan status</th>
                  <th>Risk</th>
                  <th>Attention</th>
                </tr>
              </thead>
              <tbody>
                {''.join(row_html)}
              </tbody>
            </table>
          </div>
        </section>'''
    else:
        table = '''<section class="card empty-state">
          <h2>No direct reports yet</h2>
          <p class="subtle">Add your first direct report to start tracking 1:1s, development conversations, mentors, and growth plans.</p>
          <a class="button" href="/report/new">Add direct report</a>
        </section>'''

    attention_panel = (
        f'''<section class="card">
              <div class="section-header">
                <div>
                  <h2>Needs attention</h2>
                  <p class="subtle">Quick scan of what needs follow-up right now.</p>
                </div>
              </div>
              <div class="attention-list">{''.join(attention_items)}</div>
            </section>'''
        if attention_items
        else '''<section class="card"><h2>Needs attention</h2><p class="subtle">Everything is looking good right now.</p></section>'''
    )

    body = summary_cards(reports) + attention_panel + table
    return render_layout('Dashboard', body)


def render_report_form(form: dict[str, str], error: str | None = None, report_id: int | None = None) -> bytes:
    is_edit = report_id is not None
    action = f'/report/{report_id}/edit' if is_edit else '/report/new'
    title = 'Edit direct report' if is_edit else 'Add direct report'
    error_html = f'<div class="alert error">{esc(error)}</div>' if error else ''

    def option_list(options: list[str], selected: str) -> str:
        parts = []
        for opt in options:
            sel = ' selected' if opt == selected else ''
            parts.append(f'<option value="{esc(opt)}"{sel}>{esc(opt)}</option>')
        return ''.join(parts)

    body = f'''<section class="card form-card">
      <div class="section-header">
        <div>
          <h2>{esc(title)}</h2>
          <p class="subtle">Capture the current snapshot here. Meeting dates are tracked separately in the history section.</p>
        </div>
      </div>
      {error_html}
      <form method="post" action="{action}" class="stack-form">
        <div class="form-grid two-col">
          <label>
            <span>Name *</span>
            <input type="text" name="name" value="{esc(form.get('name', ''))}" required>
          </label>
          <label>
            <span>Role / title</span>
            <input type="text" name="role_title" value="{esc(form.get('role_title', ''))}">
          </label>
          <label>
            <span>Level</span>
            <input type="text" name="level" value="{esc(form.get('level', ''))}" placeholder="L4, Senior, etc.">
          </label>
          <label>
            <span>Team</span>
            <input type="text" name="team" value="{esc(form.get('team', ''))}">
          </label>
          <label>
            <span>Mentor(s)</span>
            <input type="text" name="mentors" value="{esc(form.get('mentors', ''))}" placeholder="Comma-separated if needed">
          </label>
          <label>
            <span>Next planned 1:1</span>
            <input type="date" name="next_one_on_one_date" value="{esc(form.get('next_one_on_one_date', ''))}">
          </label>
          <label>
            <span>Personal development plan status</span>
            <select name="plan_status">{option_list(PLAN_STATUSES, form.get('plan_status', 'Not started'))}</select>
          </label>
          <label>
            <span>Risk / attention flag</span>
            <select name="risk_flag">{option_list(RISK_FLAGS, form.get('risk_flag', 'None'))}</select>
          </label>
          <label class="full-width">
            <span>Development goal summary</span>
            <textarea name="development_goal_summary" rows="4" placeholder="What are they working toward?">{esc(form.get('development_goal_summary', ''))}</textarea>
          </label>
          <label class="full-width">
            <span>Promotion readiness / growth area</span>
            <textarea name="promotion_readiness" rows="3" placeholder="Your current read on growth, trajectory, and next-level expectations">{esc(form.get('promotion_readiness', ''))}</textarea>
          </label>
          <label class="full-width">
            <span>Notes</span>
            <textarea name="notes" rows="5" placeholder="General notes, context, support needed, strengths, blockers">{esc(form.get('notes', ''))}</textarea>
          </label>
        </div>
        <div class="actions-row">
          <button class="button" type="submit">{'Save changes' if is_edit else 'Create report'}</button>
          <a class="button secondary" href="/">Cancel</a>
        </div>
      </form>
    </section>'''
    return render_layout(title, body)


def info_panel(label: str, value: str, subtle: bool = False) -> str:
    extra = ' subtle' if subtle else ''
    return f'''<section class="card mini-card">
      <p class="mini-label">{esc(label)}</p>
      <p class="mini-value{extra}">{esc(value)}</p>
    </section>'''


def render_report_detail(report_id: int, meeting_error: str | None = None) -> bytes:
    row = fetch_report(report_id)
    if not row:
        return render_not_found()

    meetings = fetch_meetings(report_id)
    meeting_error_html = f'<div class="alert error">{esc(meeting_error)}</div>' if meeting_error else ''

    summary = [
        info_panel('Role / title', row['role_title'] or 'Not set', subtle=not bool(row['role_title'])),
        info_panel('Level', row['level'] or 'Not set', subtle=not bool(row['level'])),
        info_panel('Team', row['team'] or 'Not set', subtle=not bool(row['team'])),
        info_panel('Mentor(s)', row['mentors'] or 'Not set', subtle=not bool(row['mentors'])),
        info_panel('Last 1:1', format_date(row['last_one_on_one']), subtle=row['last_one_on_one'] is None),
        info_panel('Last development conversation', format_date(row['last_dev_conversation']), subtle=row['last_dev_conversation'] is None),
        info_panel('Next planned 1:1', format_date(row['next_one_on_one_date']), subtle=row['next_one_on_one_date'] is None),
        info_panel('Plan status', row['plan_status']),
    ]

    meeting_rows = []
    for m in meetings:
        meeting_rows.append(
            f'''<tr>
                  <td>{esc(m['meeting_type'])}</td>
                  <td>{esc(format_date(m['meeting_date']))}</td>
                  <td>{esc(m['notes'] or '-')}</td>
                </tr>'''
        )

    meeting_table = (
        f'''<div class="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Type</th>
                    <th>Date</th>
                    <th>Notes</th>
                  </tr>
                </thead>
                <tbody>{''.join(meeting_rows)}</tbody>
              </table>
            </div>'''
        if meeting_rows
        else '<p class="subtle">No meetings logged yet.</p>'
    )

    attention_items = ''.join(f'<li>{esc(item)}</li>' for item in compute_attention(row)) or '<li>Nothing urgent flagged.</li>'

    body = f'''
    <section class="detail-hero">
      <div>
        <p class="eyebrow">Direct report</p>
        <h2>{esc(row['name'])}</h2>
        <div class="badge-row">
          {status_badge(row['plan_status'], variant_for_plan(row['plan_status']))}
          {status_badge(row['risk_flag'], variant_for_risk(row['risk_flag']))}
        </div>
      </div>
      <div class="actions-row">
        <a class="button" href="/report/{report_id}/edit">Edit</a>
        <form method="post" action="/report/{report_id}/delete" onsubmit="return confirm('Delete this direct report and all meeting history?');">
          <button class="button danger-outline" type="submit">Delete</button>
        </form>
      </div>
    </section>

    <section class="card-grid">{''.join(summary)}</section>

    <section class="card">
      <div class="section-header">
        <div>
          <h2>Development snapshot</h2>
          <p class="subtle">Current plan, growth context, and follow-up items.</p>
        </div>
      </div>
      <div class="detail-copy-grid">
        <div>
          <h3>Development goal summary</h3>
          <p>{esc(row['development_goal_summary'] or 'No development goals captured yet.')}</p>
        </div>
        <div>
          <h3>Promotion readiness / growth area</h3>
          <p>{esc(row['promotion_readiness'] or 'No promotion readiness notes captured yet.')}</p>
        </div>
        <div>
          <h3>General notes</h3>
          <p>{esc(row['notes'] or 'No notes captured yet.')}</p>
        </div>
        <div>
          <h3>Attention checklist</h3>
          <ul>{attention_items}</ul>
        </div>
      </div>
    </section>

    <section class="card two-pane">
      <div>
        <div class="section-header">
          <div>
            <h2>Log a meeting</h2>
            <p class="subtle">Use this for every 1:1 or development conversation. The dashboard automatically reads the latest dates.</p>
          </div>
        </div>
        {meeting_error_html}
        <form method="post" action="/meeting/new" class="stack-form compact-form">
          <input type="hidden" name="report_id" value="{report_id}">
          <label>
            <span>Meeting type</span>
            <select name="meeting_type">
              <option value="1:1">1:1</option>
              <option value="Development conversation">Development conversation</option>
            </select>
          </label>
          <label>
            <span>Date</span>
            <input type="date" name="meeting_date" value="{date.today().isoformat()}" required>
          </label>
          <label>
            <span>Notes</span>
            <textarea name="notes" rows="4" placeholder="Optional notes or outcomes"></textarea>
          </label>
          <div class="actions-row">
            <button class="button" type="submit">Add meeting</button>
          </div>
        </form>
      </div>
      <div>
        <div class="section-header">
          <div>
            <h2>Meeting history</h2>
            <p class="subtle">All recorded 1:1s and development conversations.</p>
          </div>
        </div>
        {meeting_table}
      </div>
    </section>
    '''
    return render_layout(row['name'], body)


def render_not_found() -> bytes:
    body = '''<section class="card empty-state"><h2>Not found</h2><p class="subtle">That page does not exist.</p><a class="button secondary" href="/">Back to dashboard</a></section>'''
    return render_layout('Not found', body)


class TrackerHandler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path

        if path == '/':
            return self.respond_html(render_dashboard())
        if path == '/report/new':
            return self.respond_html(render_report_form({}))
        if path == '/static/styles.css':
            return self.serve_styles()

        match = re.fullmatch(r'/report/(\d+)', path)
        if match:
            return self.respond_html(render_report_detail(int(match.group(1))))

        match = re.fullmatch(r'/report/(\d+)/edit', path)
        if match:
            report = fetch_report(int(match.group(1)))
            if not report:
                return self.respond_html(render_not_found(), status=HTTPStatus.NOT_FOUND)
            return self.respond_html(render_report_form(dict(report), report_id=int(match.group(1))))

        self.respond_html(render_not_found(), status=HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        form = self.parse_form_data()

        if path == '/report/new':
            ok, error, new_id = upsert_report(None, form)
            if ok and new_id is not None:
                return self.redirect(f'/report/{new_id}')
            return self.respond_html(render_report_form(form, error=error), status=HTTPStatus.BAD_REQUEST)

        match = re.fullmatch(r'/report/(\d+)/edit', path)
        if match:
            report_id = int(match.group(1))
            ok, error, _ = upsert_report(report_id, form)
            if ok:
                return self.redirect(f'/report/{report_id}')
            return self.respond_html(
                render_report_form(form, error=error, report_id=report_id),
                status=HTTPStatus.BAD_REQUEST,
            )

        match = re.fullmatch(r'/report/(\d+)/delete', path)
        if match:
            delete_report(int(match.group(1)))
            return self.redirect('/')

        if path == '/meeting/new':
            ok, error, report_id = add_meeting(form)
            if ok and report_id is not None:
                return self.redirect(f'/report/{report_id}')
            if report_id is not None:
                return self.respond_html(render_report_detail(report_id, meeting_error=error), status=HTTPStatus.BAD_REQUEST)
            return self.redirect('/')

        self.respond_html(render_not_found(), status=HTTPStatus.NOT_FOUND)

    def parse_form_data(self) -> dict[str, str]:
        length = int(self.headers.get('Content-Length', '0'))
        body = self.rfile.read(length).decode('utf-8')
        parsed = parse_qs(body, keep_blank_values=True)
        return {key: values[0] if values else '' for key, values in parsed.items()}

    def respond_html(self, payload: bytes, status: HTTPStatus = HTTPStatus.OK) -> None:
        self.send_response(status)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def serve_styles(self) -> None:
        css_path = STATIC_DIR / 'styles.css'
        payload = css_path.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header('Content-Type', 'text/css; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def redirect(self, location: str) -> None:
        self.send_response(HTTPStatus.SEE_OTHER)
        self.send_header('Location', location)
        self.end_headers()

    def log_message(self, format: str, *args: Any) -> None:
        return


def main() -> None:
    init_db()
    server = ThreadingHTTPServer((HOST, PORT), TrackerHandler)
    print(f'Direct Report Tracker running on http://{HOST}:{PORT}')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
